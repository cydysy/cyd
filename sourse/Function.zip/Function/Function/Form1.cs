﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;

namespace Function
{
    public partial class Form1 : Form
    {
        private static System.Diagnostics.Process p;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = System.Environment.CurrentDirectory+@"\AI_InstantAI.exe";
                p.Start();
            
         
            p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
            
        }
        private void button2_Click_1(object sender, EventArgs e)
        {
          
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = System.Environment.CurrentDirectory + @"\AO_StaticAO.exe";
                p.Start();
          
            p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
           
                p = new System.Diagnostics.Process();
                p.StartInfo.FileName = System.Environment.CurrentDirectory + @"\DO_StaticDO.exe";
                p.Start();
            p.StartInfo.WindowStyle = System.Diagnostics.ProcessWindowStyle.Normal;
        }
    }
}
